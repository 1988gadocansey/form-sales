<?php

return [

	'dashboard' 			=> 'Dashboard',
	'customers' 			=> 'Pelanggan',
	'employees'				=> 'Pegawai',
	'items' 				=> 'Barang',
	'item_kits' 			=> 'Barang Paket',
	'suppliers' 			=> 'Pemasok',
	'receivings' 			=> 'Penerimaan',
	'sales' 				=> 'Penjualan',
	'reports' 				=> 'Laporan',
	'receivings_report' 	=> 'Laporan Penerimaan',
	'sales_report' 			=> 'Laporan Penjualan',
	'logout'				=> 'Keluar',
	'application_settings' 	=> 'Pengaturan Aplikasi'

];
