<?php

return [

	'sales_register' => 'Daftar Penjualan',
	'search_item' => 'Cari Barang:',
	'invoice' => 'Faktur',
	'employee' => 'Pegawai',
	'payment_type' => 'Jenis Pembayaran',
	'customer' => 'Pelanggan',
	'item_id' => 'ID Barang',
	'item_name' => 'Nama Barang',
	'price' => 'Harga',
	'quantity' => 'Quantity',
	'total' => 'Total',
	'add_payment' => 'Pembayaran',
	'comments' => 'Komentar',
	'grand_total' => 'TOTAL:',
	'amount_due' => 'Tersisa',
	'submit' => 'Selesaikan Penjualan',
	//struk
	'sale_id' => 'ID Penjualan',
	'item' => 'Barang',
	'price' => 'Harga',
	'qty' => 'Qty',
	'print' => 'Cetak',
	'new_sale' => 'Penjualan Baru',

];
