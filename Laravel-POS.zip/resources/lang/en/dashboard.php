<?php

return [

	'welcome' 			=> 'Welcome TTU Admissions Forms Sales.',
	'statistics' 		=> 'Statistics',
	 
	'total_customers' 	=> 'Total Customers',
	 
	'total_items' 		=> 'Total Forms',
	'total_item_kits' 	=> 'Form Categories',
	'total_receivings' 	=> 'Total Receivings',
	'total_sales' 		=> 'Total Sales',

];
