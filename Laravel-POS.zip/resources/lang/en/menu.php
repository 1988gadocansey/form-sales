<?php

return [

	'dashboard' 			=> 'Home',
	'customers' 			=> 'Customers',
	 
	'items' 				=> 'Forms',
	'item_kits' 			=> 'Form Categories',
	 
	'sales' 				=> 'Sales',
	'reports' 				=> 'Reports',
 
	'sales_report' 			=> 'Sales Report',
	'logout'				=> 'Logout',
	'application_settings' 	=> 'Application Settings'

];
