<?php

return [

	'list_items'	=> 'Forms',
	 
	 
	'item_name' 	=> 'Form Serial No',
	'size' 			=> 'Form Pin Code',
	 
	'selling_price' => 'Selling Price',
	 
	//inventory
	'inventory_data_tracking' => 'Inventory Data Tracking',
	'current_quantity' => 'Current Quantity',
	'inventory_to_add_subtract' => 'Inventory to add/subtract',
	'comments' => 'Comments',
	'employee' => 'Employee',
	'in_out_qty' => 'In/Out Qty',
	'remarks' => 'Remarks',

];
