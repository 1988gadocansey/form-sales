<?php

return [

	'sales_register' => 'Sales Register',
	'search_item' => 'Search Item:',
	'invoice' => 'Invoice',
	'employee' => 'Vendor',
	'payment_type' => 'Payment Type',
	'customer' => 'Customer',
	'item_id' => 'Item ID',
	'item_name' => 'Item Name',
	'price' => 'Price',
	'quantity' => 'Quantity',
	'total' => 'Total',
	'add_payment' => 'Add Payment',
	'comments' => 'Comments',
	'grand_total' => 'TOTAL:',
	'amount_due' => 'Change due',
	'submit' => 'Complete Sale',
	//struk
	'sale_id' => 'Sale ID',
	'item' => 'Item',
	'price' => 'Price',
	'qty' => 'Qty',
	'print' => 'Print',
	'new_sale' => 'New Sale',

];
