<?php

return [

    'item_kits' => 'Combos de Productos',
    'new_item_kit' => 'Nuevo Combo',
    'item_kit_id' => 'ID',
    'item_kit_name' => 'Nombre del Combo',
    'cost_price' => 'Costo',
    'selling_price' => 'Precio',
    'item_kit_description' => 'Descripción',
    'search_item' => 'Buscar Producto:',
    'description' => 'Descripción',
    'quantity' => 'Cantidad',
    'profit' => 'GANANCIA:',
    'item_id' => 'ID',
    'item_name' => 'Producto',
    'submit' => 'Guardar',
];
