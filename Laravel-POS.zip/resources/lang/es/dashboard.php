<?php

return [

    'welcome' => 'Bienvenido a TutaPOS - TUTA Punto de Venta.',
    'statistics' => 'Estadísticas',
    'total_employees' => 'Total Empleados',
    'total_customers' => 'Total Clientes',
    'total_suppliers' => 'Total Proveedores',
    'total_items' => 'Total Productos',
    'total_item_kits' => 'Total Combos',
    'total_receivings' => 'Total Compras',
    'total_sales' => 'Total Ventas',
];
