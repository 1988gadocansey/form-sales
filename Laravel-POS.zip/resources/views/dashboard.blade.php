@extends('app') @section('content')
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
		<center><p style="text-align: ;"><h2><i class="glyphicon glyphicon-th-list"></i>&nbsp;&nbsp;Form Sales Guidelines </h2></p></center>
				<div style="text-align: ; position: relative; color: orange; margin-top:0px; background-color: #ddd; padding: 10px; min-height: 300px">
    
    <div style="margin-left: 100px" >
   
  
                                 
                                <p>1.Insist that all details of the applicants are entered</p>
                                <p>2.Make sure the phone number provided is for the applicant himself  since sms notifications will be send to the applicants during the admission process</p>
                                <p>3.Wait for the system to prompt you that transaction completed successfully before checking out</p>
                                <p>4.All HND(Regular and Mature) are to purchase HND form </p>
                                <p>5.All BTECH Top ups are to purchase BTECH form </p>
                                <p>6.All Certificates are to purchase Certificate forms </p>
                                <p>7.All Diploma applicants are to purchase Diploma form </p>
                                <p>8.All Distance applicants are to purchase Distance form </p>
                                <p>9.All Access applicants are to purchase Access form </p>
                                <p>10.SMS of voucher code will be forward to email and phone</p>
                                <p>11.You are responsible for any form of financial transactions on this page</p>
                                <p>12.Remember to logout after daily sales or when you are idle</p>
                                <p><strong> </strong></p>
                                <p><strong>CLOSING DATE</strong></p>
                                <p>13.Closing date for sale of admissions form is 24th June 2017 .................</p>
                                <p>14.Enquires may be addressed to:</p>
                                <p>The Registrar<br/>Takoradi Technical University</p>
      </div>

      <center> 
       Hotlines 0246091283,0276363053,0249403322,0505284060 
     </center>
                  
</div>

						 
		</div>
	</div>
	 
</div>
@endsection
